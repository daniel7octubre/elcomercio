<?php

$app->get('/', function ($request, $response) {
    
    $this->logger->info("Developers.sac '/' route");
    return $response->withRedirect('listado_empleados');

});

$app->get('/listado_empleados[{:email}]', function ($request, $response) {

    $email = '';
    $data_view = [];

    $query = $request->getQueryParams();
	$listado_empleados = $this->empleados;

	if(isset($query['email'])){

		$email = $query['email'];

		if(trim($email)!=''){

			$listado_empleados = [];

			foreach ($this->empleados as $value) {

				$existe = strpos($value['email'], $email);

				if ($existe!==false) {
					$listado_empleados[] = $value; 
				}

			}
		}
	}

    $data_view['email'] = $email;
	$data_view['listado_empleados'] = $listado_empleados;
	
    return $this->renderer->render($response, 'listado_empleados.phtml', $data_view);

})->setName('listado_empleados');


$app->get('/info_empleado[{:id}]', function ($request, $response) {

    $data_view = [];
    $info_empleado = [];

	$query = $request->getQueryParams();

	foreach ($this->empleados as $value) {

		if ($value['id']==$query['id']) {
			$info_empleado = $value;
		}

	}

	$data_view['info_empleado'] = $info_empleado;

    return $this->renderer->render($response, 'info_empleado.phtml', $data_view);

})->setName('info_empleado');
